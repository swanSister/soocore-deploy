//
//  ViewController.swift
//  soocore
//
//  Created by swan on 08/08/2019.
//  Copyright © 2019 swan. All rights reserved.
//

import UIKit
import WebKit
import os.log

class ViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    var webView: WKWebView!
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    let VVURLSchemeDataDidParseNotification = "VVURLSchemeDataDidParseNotification"
    override func loadView() {
        webView = WKWebView()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        view = webView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        if(appDelegate.path != nil){
//            os_log("url = %@", appDelegate.path)
//        }else{
//            os_log("url scheme is nil")
//        }
        os_log("viewDidLoad")
        NotificationCenter.default.addObserver(self, selector:#selector(ViewController.handleNotification(_:)), name: NSNotification.Name(VVURLSchemeDataDidParseNotification), object: nil)
        let url = URL(string: "https://soo-core.com")!
        webView.load(URLRequest(url: url))
        
        // 2
        let refresh = UIBarButtonItem(barButtonSystemItem: .refresh, target: webView, action: #selector(webView.reload))
        toolbarItems = [refresh]
        navigationController?.isToolbarHidden = false
    }
    
    @objc func handleNotification(_ notification: NSNotification) {
        if notification.name.rawValue == VVURLSchemeDataDidParseNotification {
            if let object = notification.object as? [String: String] {
                os_log("url = %@", object)
                if(object["id"] != nil){
                    let url = URL(string: "https://soo-core.com/#/?id="+object["id"]!)!
                    webView.load(URLRequest(url: url))
                }else if(object["sectionId"] != nil){
                    let url = URL(string: "https://soo-core.com/#/?sectionId="+object["sectionId"]!)!
                    webView.load(URLRequest(url: url))
                }
            }
        }
    }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        
        let alertController = UIAlertController(title: nil, message: message, preferredStyle: .actionSheet)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
            completionHandler()
        }))
        
        present(alertController, animated: true, completion: nil)
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = navigationAction.request.url, url.scheme != "http" && url.scheme != "https" {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
        }
        else {
            decisionHandler(.allow)
        }
    }
}

